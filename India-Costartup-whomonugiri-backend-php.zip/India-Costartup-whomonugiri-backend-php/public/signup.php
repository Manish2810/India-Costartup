<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sign Up</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="Register Form/images/icons/123.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css"> 
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.js" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


<!--============================google map API key===================================================================-->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=AIzaSyDyHHInMdnJMI3Q-MeZxO1r4XHEFm6clyk"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/css/intlTelInput.css" rel="stylesheet" media="screen">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/intlTelInput.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/intlTelInput.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"></script>
  <!--============================================view tips===================================================-->
    <style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
@media all and (max-width: 500px) {
  .modal {
   padding-top: 10px; 
   overflow: scroll;   
      
  }
}
@media all and (max-width: 500px) {
  .modal-content {
  width: 90%;
      
      
  }
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 90%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>
 <!--===============================================================================================-->  
<style>
		[x-cloak] {
			display: none;
		}

		[type="checkbox"] {
			box-sizing: border-box;
			padding: 0;
		}

		.form-checkbox,
		.form-radio {
			-webkit-appearance: none;
			-moz-appearance: none;
			appearance: none;
			-webkit-print-color-adjust: exact;
			color-adjust: exact;
			display: inline-block;
			vertical-align: middle;
			background-origin: border-box;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			flex-shrink: 0;
			color: currentColor;
			background-color: #fff;
			border-color: #e2e8f0;
			border-width: 1px;
			height: 1.4em;
			width: 1.4em;
		}

		.form-checkbox {
			border-radius: 0.25rem;
		}

		.form-radio {
			border-radius: 50%;
		}

		.form-checkbox:checked {
			background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M5.707 7.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4a1 1 0 0 0-1.414-1.414L7 8.586 5.707 7.293z'/%3e%3c/svg%3e");
			border-color: transparent;
			background-color: currentColor;
			background-size: 100% 100%;
			background-position: center;
			background-repeat: no-repeat;
		}
		
		.form-radio:checked {
			background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
			border-color: transparent;
			background-color: currentColor;
			background-size: 100% 100%;
			background-position: center;
			background-repeat: no-repeat;
		}
	
	
	.intl-tel-input.allow-dropdown input, .intl-tel-input.allow-dropdown input[type=text], .intl-tel-input.allow-dropdown input[type=tel], .intl-tel-input.separate-dial-code input, .intl-tel-input.separate-dial-code input[type=text], .intl-tel-input.separate-dial-code input[type=tel]{
	padding-right: 100px;	
		
	}
.intl-tel-input.separate-dial-code .selected-dial-code{
	background-color:transparent;
	}
	
	#otpinput {
  padding-left: 10px;
  letter-spacing: 42px;
  border:none;
  outline:none;
  background-image: linear-gradient(to left, black 70%, rgba(255, 255, 255, 0) 0%);
  background-position: bottom;
  background-size: 50px 2px;
  background-repeat: repeat-x;
  
  width: 220px;
  min-width: 220px;
}
	#divInner{
  left: 0;
  position: sticky;
}

#divOuter{
  width: 190px; 
  overflow: hidden;
}

	</style>
	
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Register Form/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	
<!--===============================================================================================-->
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
    
    
    
    <!------------------------------------For Location---------------------------------------------------->
    
    <script>
var searchInput = 'search_input';

$(document).ready(function () {
    var autocomplete;
    autocomplete = new google.maps.places.Autocomplete((document.getElementById(searchInput)), {
        types: ['geocode'],
    });
	
    google.maps.event.addListener(autocomplete, 'place_changed', function () {
        var near_place = autocomplete.getPlace();
        document.getElementById('loc_lat').value = near_place.geometry.location.lat();
        document.getElementById('loc_long').value = near_place.geometry.location.lng();
		
        document.getElementById('latitude_view').innerHTML = near_place.geometry.location.lat();
        document.getElementById('longitude_view').innerHTML = near_place.geometry.location.lng();
    });
});
		$(document).on('change', '#'+searchInput, function () {
    document.getElementById('latitude_input').value = '';
    document.getElementById('longitude_input').value = '';
	
    document.getElementById('latitude_view').innerHTML = '';
    document.getElementById('longitude_view').innerHTML = '';
});
</script>
<!--------------end location----------------------------------------------------------------------->    
</head>
<body>
	
<body class="antialiased sans-serif bg-gray-150">
	<div x-data="app()" x-cloak>
		<div class="max-w-3xl mx-auto px-4 py-10">

			<div x-show.transition="step === 'complete'">
				<div class="bg-white rounded-lg p-10 flex items-center shadow justify-between">
					<div>
						<svg class="mb-4 h-20 w-20 text-green-500 mx-auto" viewBox="0 0 20 20" fill="currentColor">  <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>

						<h2 class="text-2xl mb-4 text-gray-800 text-center font-bold">Registration Success</h2>

					<center><div class="text-gray-600 mb-8">
							Congratulations! Your Profile Has Been Registered Succesfully. You Are All Set For Your Matches.
						</div></center>

						<a href="signin.php"
							class="w-40 block mx-auto focus:outline-none py-2 px-5 rounded-lg shadow-sm text-center text-gray-600 bg-white hover:bg-gray-100 font-medium border" 
						>Go To Profile</a>
					</div>
				</div>
			</div>
	
			<div x-show.transition="step != 'complete'">
				<div class="border-b-2 ">
				<label for="logo" class="text-2xl font-bold mb-1 text-blue-600 block -my-6">India Costartup</label>
				</div>
				<br>
				<center><div class="text-xl font-bold text-gray-700 leading-tight">Let's Create Your Profile</div></center>

				<div class="mx-auto w-100 text-gray-500 text-xs text-center mt-1">This Information Will Let Us know More About You.</div>
				<p style="text-align:center;color:red;font-weight:bold" id="e_m"></p>
				<!-- Top Navigation -->
				<div class="border-b-2 py-5">
					
					<div class="uppercase tracking-wide text-xs font-bold text-gray-500 mb-1 leading-tight" x-text="`Step: ${step} of 12`"></div>
					<div class="flex flex-col md:flex-row md:items-center md:justify-between">
						<div class="flex-1">
							<div x-show="step === 1">
								<div class="text-base font-bold text-gray-700 leading-tight">What Is Your Full Name?</div>
							</div>
							
							<div x-show="step === 2">
								<div class="text-base font-bold text-gray-700 leading-tight">Tell Me About Yourself</div>
							</div>
							<div x-show="step === 3">
								<div class="text-base font-bold text-gray-700 leading-tight">Location</div>
							</div>
							<div x-show="step === 4">
								<div class="text-base font-bold text-gray-700 leading-tight">What Is Your Highest Qualification?</div>
							</div>
							<div x-show="step === 5">
								<div class="text-base font-bold text-gray-700 leading-tight">Where Are You Currently Working?</div>
							</div>
							<div x-show="step === 6">
								<div class="text-base font-bold text-gray-700 leading-tight">Business Details</div>
							</div>
							<div x-show="step === 7">
								<div class="text-base font-bold text-gray-700 leading-tight">Business Details</div>
							</div>
							<div x-show="step === 8">
								<div class="text-base font-bold text-gray-700 leading-tight">Business Details</div>
							</div>
							<div x-show="step === 9">
								<div class="text-base font-bold text-gray-700 leading-tight">Contact Details</div>
							</div>
							<div x-show="step === 10">
								<div class="text-base font-bold text-gray-700 leading-tight">Contact Details</div>
							</div>
							<div x-show="step === 11">
								<div class="text-base font-bold text-gray-700 leading-tight">Your Password</div>
							</div>
							<div x-show="step === 12">
								<div class="text-base font-bold text-gray-700 leading-tight">Upload Your Photo</div>
							</div>
						</div>

						<div class="flex items-center md:w-64">
							<div class="w-full bg-gray-300 rounded-full mr-2">
								<div class="rounded-full bg-green-500 text-xs leading-none h-2 text-center text-white" :style="'width: '+ parseInt(step / 12 * 100) +'%'"></div>
							</div>
							<div class="text-xs w-10 text-gray-600" x-text="parseInt(step / 12 * 100) +'%'"></div>
						</div>
					</div>
				</div>
				<!-- /Top Navigation -->
				<form id="signup_form" method="post" action="../includes/create_new_account.php" enctype="multipart/form-data">
				<!-- Step Content -->
				<div class="py-10">	
					<div x-show.transition.in="step === 1">
				

						<div class="mb-5">
							<label for="firstname" class="font-bold mb-1 text-gray-700 block">First Name</label>
							<input type="text" id="name" name="first_name" style="text-transform:capitalize" required
								class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium"
								placeholder="Enter your first name ...">
						</div>

						<div class="mb-5">
							<label for="lastname" class="font-bold mb-1 text-gray-700 block">Last Name</label>
							<input type="text" id="name" name="last_name" style="text-transform:capitalize" required
								class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium"
								placeholder="Enter your last name...">
						</div>

					</div>
						<div x-show.transition.in="step === 2">
						<div class="mb-5">
							<label for="email" class="font-bold mb-1 text-gray-700 block">Gender</label>
							
							<div class="flex">
								<label
									class="flex justify-start items-center text-truncate rounded-lg bg-gray-200 pl-4 pr-6 py-3 shadow-sm mr-4">
									<div class="text-blue-600 mr-3">
										<input type="radio" x-model="gender"name="gender" value="Male" class="form-radio focus:outline-none focus:shadow-outline" />
									</div>
									<div class="select-none text-gray-700">Male</div>
								</label>

								<label
									class="flex justify-start items-center text-truncate rounded-lg bg-gray-200 pl-4 pr-6 py-3 shadow-sm">
									<div class="text-blue-600 mr-3">
										<input type="radio" x-model="gender" name="gender" value="Female" class="form-radio focus:outline-none focus:shadow-outline" />
									</div>
									<div class="select-none text-gray-700">Female</div>
								</label>
							</div>
						</div>

						<div class="mb-5">
							<label for="DOB" class="font-bold mb-1 text-gray-700 block">Date Of Birth</label>
							<input type="tel" id="js-date" maxlength="10"  name="d_o_b"
								class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium"
								placeholder="DD-MM-YYYY">
						</div>
							
							
							
							
					</div>
					<div x-show.transition.in="step === 3">
						<div class="mb-5">
							<label for="location" class="font-bold mb-1 text-gray-700 block">Your Location</label>
							
   
   <div class="form-group">
  
    <input type="text" class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium" name="location" id="search_input" placeholder="City / District / State" />
    <input type="hidden" name="loc_lat" id="loc_lat" />
    <input type="hidden" name="loc_long" id="loc_long" />
</div>

								
						</div></div>
					<div x-show.transition.in="step === 4">
						<div class="mb-5">
							<label for="qualification" class="font-bold mb-1 text-gray-700 block">Your Highest Qualification</label>
							 <select id="dropdown" name="qualification" required class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium"> 
					<option value="" disabled="" selected="selected">Choose Your Highest Qualification</option>    
                             
                             <option value="1">Bachelors</option>
                             <option value="2">Masters</option>
                             <option value="3">Doctorate</option>
                             <option value="4">Diploma</option>
                             <option value="5">Trade School</option>
                             <option value="6">High School</option>
                             <option value="7">Less Than High School</option>
                             <option value="8">Bachelors- Adminstrative Services</option>
                             <option value="9">Bachelors- Advertising/ Marketing</option>
                             <option value="10">Bachelors- Architecture</option>
                             <option value="11">Bachelors- Arts</option>
                             <option value="12">Bachelors- Commerce</option>
                             <option value="13">Bachelors- Computer/ IT</option>
                             <option value="14">Bachelors- Education</option>
                             <option value="15">Bachelors- Engineering/ Technology</option>
                             <option value="16">Bachelors- Fashion</option>
                             <option value="17">Bachelors- Finance</option>
                             <option value="18">Bachelors- Fine Arts</option>
                             <option value="19">Bachelors- Home Science</option>
                             <option value="20">Bachelors- Law</option>
                             
                             <option value="21">Bachelors- Management</option>
                             <option value="22">Bachelors- Medicine</option>
                             <option value="23">Bachelors- Nursing/ Health Science</option>
                             <option value="24">Bachelors- Office Adminstartion</option>
                             <option value="25">Bachelors- Science</option>
                             <option value="26">Bachelors- Shipping</option>
                             <option value="27">Bachelors- Travel & Tourism</option>
                             <option value="28">Masters- Adminstrative Services</option>
                             <option value="29">Masters- Advertising/ Marketing</option>
                             <option value="30">Masters- Architecture</option>
                             <option value="31">Masters- Armed Forces</option>
                             <option value="32">Masters- Arts</option>
                             <option value="33">Masters- Commerce</option>
                             <option value="34">Masters- Computer/ IT</option>
                             <option value="35">Masters- Education</option>
                             <option value="36">Masters- Engineering/ Technology</option>
                             <option value="37">Masters- Fashion</option>
                             <option value="38">Masters- Finance</option>
                             <option value="39">Masters- Fine Arts</option>
                             <option value="40">Masters- Home Science</option>
                             <option value="41">Masters- Law</option>
                             <option value="42">Masters- Management</option>
                            
                             <option value="43">Masters- Medicine</option>
                             <option value="44">Masters- Nursing/ Health Science</option>
                             <option value="45">Masters- Office Adminstration</option>
                             <option value="46">Masters- Science</option>
                             <option value="47">Masters- Shipping</option>
                             <option value="48">Masters- Travel & Tourism</option>
                             <option value="49">Doctorate- Adminstrative Services</option>
                             <option value="50">Doctorate- Advertising/ Marketing</option>
                             <option value="51">Doctorate-  Architecture</option>
                             <option value="52">Doctorate- Armed Forces</option>
                             <option value="53">Doctorate- Arts</option>
                             <option value="54">Doctorate- Commerce</option>
                             <option value="55">Doctorate- Computer/ IT</option>
                             <option value="56">Doctorate- Education</option>
                             <option value="57">Doctorate- Engineering/ Technology</option>
                             <option value="58">Doctorate- Fashion</option>
                             <option value="59">Doctorate- Finance</option>
                             <option value="60">Doctorate- Fine Arts</option>
						      <option value="61">Doctorate- Home Science</option>
                             <option value="62">Doctorate- Law</option>
                             <option value="63">Doctorate- Management</option>
                             <option value="64">Doctorate- Medicine</option>
                             <option value="65">Doctorate- Nursing/ Health Science</option>
                             <option value="66">Doctorate- Office Adminstration</option>
                             <option value="67">Doctorate- Science</option>
                             <option value="68">Doctorate- Shipping</option>
                             <option value="69">Doctorate- Travel & Tourism</option>
                             <option value="70">Diploma- Adminstrative Services</option>
							 <option value="71">Diploma- Advertising/ Marketing</option>
                             <option value="72">Diploma-  Architecture</option>
                             <option value="73">Diploma- Armed Forces</option>
                             <option value="74">Diploma- Arts</option>
                             <option value="75">Diploma- Commerce</option>
                             <option value="76">Diploma- Computer/ IT</option>
                             <option value="77">Diploma- Education</option>
                             <option value="78">Diploma- Engineering/ Technology</option>
                             <option value="79">Diploma- Fashion</option>
                             <option value="80">Diploma- Finance</option>
							 <option value="81">Diploma- Fine Arts</option>
                             <option value="82">Diploma- Home Science</option>
                             <option value="83">Diploma- Law</option>
                             <option value="84">Diploma- Management</option>
                             <option value="85">Diploma- Medicine</option>
                             <option value="86">Diploma- Nursing/ Health Science</option>
                             <option value="87">Diploma- Office Adminstration</option>
                             <option value="88">Diploma- Science</option>
							 <option value="86">Diploma- Shipping</option>
                             <option value="87">Diploma- Travel & Tourism</option>
                            
							</select>	
						</div></div>
					
					<div x-show.transition.in="step === 5">
						<div class="mb-5">
							<label for="working" class="font-bold mb-1 text-gray-700 block">Currently Working In</label>
							 <select id="dropdown" name="working_status" required class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium">
					<option value="" disabled="" selected="selected">Currently Working In</option>    
                             <option value="1">Private Company</option>
                             <option value="2">Government Or Public Sector</option>
                             <option value="3">Defence Or Civil Services</option>
                             <option value="4">Business Or Self Employed</option>
                             <option value="5">Non-working</option>
                     
                            
							</select>	
						</div></div>
					
					
					<div x-show.transition.in="step === 6">
						<div class="mb-5">
							<label for="business" class="font-bold mb-1 text-gray-700 block">Looking For</label>
							 <select id="dropdown" name="looking_for" required class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium">
					 <option value="" disabled="" selected="selected">Looking For</option>
                        <option value="1">Startup Or Business</option>
                        <option value="2">Partner</option>
							</select>	
						</div>
					
						
						<div class="mb-5">
							<label for="business" class="font-bold mb-1 text-gray-700 block">Business Field</label>
							 <select  id="businessfield"  name="business[]" required class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline  text-gray-600 bg-gray-200 font-medium "  multiple="" placeholder="Choose Business Field">
                            
                             <option value=""disabled selected>Business Field</option>
                             <option>Aerospace</option>
                             <option>Advertising & Marketing</option>
                             <option>Agriculture</option>
                             <option >Art & Design</option>
                             <option >Automobile</option>
                             <option >Banking Fianance & Insurance</option>
                             <option >Beauty & Fitness</option>
                             <option >Consultancy</option>
                             <option >Defence & Security</option>
                             <option >Ecommerce</option>
                             <option >Education</option>
                             <option >Electrical & Electronic</option>
                             <option >Energy Alternative</option>
                             <option >Event Planning</option>
                             <option >Fashion</option>
                             <option >Farm</option>
                             <option >Food & Beverage</option>
                             <option >Hardware</option>
                             <option >Hotel & Restaurant</option>
                             <option >Hospital & Healthcare</option>
                             <option >Import & Export</option>
                             <option >Legal Service</option>
                             <option >Manufacturing</option>
                             <option >Mall & Multiplex</option>
                             <option >Media Film & Entertainment</option>
                             <option >Medical & Pharma</option>
                             <option >Mining, Oil & Gas</option>
                             <option >Network Marketing</option>
                             <option >Real Estate & Construction</option>
                             <option >Rent & Lease</option>
                             <option >Retailer Shop</option>
                             <option >Showroom</option>
                             <option >Software</option>
                             <option >Sport & Game</option>
                             <option >Supermarket & Mart</option>
                             <option >Telecommunication</option>
                             <option >Transport</option>
                             <option >Travel & Tourism</option>
                             <option >Wholesaler Shop</option>
                             <option >Web & Internet Service</option>
                          
                            
             
                        </select>
							
						</div>
						<div class="text-gray-600 mt-2 mb-4">
							Instruction

								<ul class="list-disc text-sm ml-4 mt-2">
									<li>You have to choose only two business field as per your interest.</li>
								
									
								</ul>	
							</div>	
					
						
					</div>
					
					
					<div x-show.transition.in="step === 7">
						<div class="mb-5">
							<label for="plan" class="font-bold mb-1 text-gray-700 block">Write About Your Business Or Startup Plan</label>
							<div class="text-gray-600 mt-2 mb-4">
							Instructions

								<ul class="list-disc text-sm ml-4 mt-2">
									<li>This section will help you to make a strong impression on your potential partner. so, express about your startup or business plan.</li>
									
									<li>This will be screened everytime by our service executive team when you update it. </li>
									
								</ul>	
							</div>
							
						
							<textarea rows="5" cols="20" name="business_about" class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium" placeholder="Write here...">
</textarea>
						<button id="myBtn"
							  class="text-blue-600 mt-2 ml-4 font-bold underline">
								Writing tips
									</button>
							             <!-- Writing tips -->
                            <div id="myModal" class="modal">

                                <!-- Modal content -->
                                <div class="modal-content">
                            <span class="close">&times;</span>
									
                            <center><div class="text-xl font-bold text-gray-700 leading-tight">Writing Tips</div></center> 
									
                            <label for="example" class="font-bold mb-1 text-gray-700 block">Example-1</label>
                            <div class="border-b-2 ">        
                            <p>I have a business idea. I want to setup a manufacturing unit of spices in my city (eg. Delhi). I have a good experience about spices. I need a partner who works closely with me in this. </p>
                                    </div>
                                <label for="example" class="font-bold mb-1 text-gray-700 block">Example-2</label>
                            <div class="border-b-2 ">   
                              <p>I have an experience of 5 years in Real-estate business. I am going to build an apartment in Mumbai. I need a partner who can make an equal investment with me. so, that they will get good profilts. </p>  
                                
                                </div>
                            <label for="example" class="font-bold mb-1 text-gray-700 block">Example-3</label>
                       <div class="border-b-2 ">
                 <p>I want to do a grocery wholesaler or retailer business. There is a lot of demand in my market place. I don't have any experience but I want a partner with experience in this field who can help me to grow this business with me.</p>
                                </div>
                         <label for="example" class="font-bold mb-1 text-gray-700 block">Example-4</label>
                           <p>
                             I have one Acre cultivated land in (eg. Punjab). I want to cultivate Aloe Vera. The profit in this farm is very good. I have good knowledge in marketing. I need a pertner from my city (eg. punjab) whio can pursue this work in partnership with less investment.</p>
                                    </div>
                                    </div>
						</div></div>
					
					
					<div x-show.transition.in="step === 8">
						<div class="mb-5">
							<label for="plan" class="font-bold mb-1 text-gray-700 block">How Much Your Investment Plan ?</label>
							
						<select id="dropdown" name="businessplan" required class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium">
					<option value="" disabled="" selected="selected">Choose Any One Of The Following</option>    
                             <option value="1">0 - 50 Thousand</option>
                             <option value="2">50 Thousand- 1 Lakh </option>
                             <option value="3">1 Lakh - 5 Lakh</option>
                             <option value="4">5 Lakh - 10 Lakh</option>
                             <option value="5">10 Lakh - 25 Lakh</option>
							 <option value="6">25 Lakh - 50 Lakh</option>
                             <option value="7">50 Lakh - 1 Crore</option>
                             <option value="8">1 Crore - 5 Crore</option>
							<option value="9">5 Crore - 10 Crore</option>
							<option value="10">10 Crore - Above</option>
                            
							</select>	
							
							<div class="text-gray-600 mt-2 mb-4">
							Instructions

								<ul class="list-disc text-sm ml-4 mt-2">
									<li>We already know that there is no business without investment.</li>
									<li>Almost every business needs investment.</li>
									<li>But don't worry about it, there are lots of business that you can start with minimal investment.</li>
									<li>If you want to invest your time, energy and efforts in your business and don't want to invest money, you can proceed with skip button.</li>
								</ul>	
							</div>
							<button 
							x-show="step < 11"
							@click="step++"  class="text-blue-600 mt-2 ml-4 font-bold underline">
								Skip
									</button>
							
							
							
						</div></div>
					<div x-show.transition.in="step === 9">
							<div class="mb-5">
							<label for="email" class="font-bold mb-1 text-gray-700 block">Email</label>
							<input type="text"  name="email"
								class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium"
								placeholder="Enter your email...">
						</div>
						
						
						
						
						
					</div>
						
						
						
						
					<div x-show.transition.in="step === 10">
					<div class="mb-5" id="mb">
							<label for="number" class="font-bold mb-1 text-gray-700 block">Mobile Number</label>
						<div class="text-gray-600 mt-2 mb-4">
							We need to verify your mobile number.

								<ul class="list-disc text-sm ml-4 mt-2">
									
									<li>We will send you a one time password on your mobile number.</li>
									
								</ul>	
							</div>
							<input   id="phone" name="mobile" type="tel"
								class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium">
						</div>

						<button id="send" class="w-25 focus:outline-none border border-transparent py-2 px-4 rounded-lg shadow-sm text-center text-sm text-white bg-blue-500 hover:bg-blue-600 font-medium">Send OTP</button>
							
						<div class="mb-5" id="otp">
							<label for="otp"  class="font-bold mb-1 text-gray-700 block">Enter OTP</label> <br>
							 <i class="fa fa-arrow-left"  aria-hidden="true" style="font-size:20px;"></i>
							<div class="text-gray-600 mt-2 mb-4">
							Making sure it's you.
								<ul class="list-disc text-sm ml-4 mt-2">
									
									<li>You will get a OTP via SMS.</li>
									
								</ul>	
							</div><br>
							<div id="divOuter">
 							 <div id="divInner">
							<input type="number" id="otpinput" name="otp" 
							 maxlength="4"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  onKeyPress="if(this.value.length==4) return false;"/>
								</div></div>
								</div>
						<button id="verify" class="w-25 focus:outline-none border border-transparent py-2 px-4 rounded-lg shadow-sm text-center text-sm text-white bg-blue-500 hover:bg-blue-600 font-medium">Verify OTP</button>
						<button 
							id="resend"  class="text-blue-600 mt-2 ml-4 font-bold underline">
								Resend OTP
									</button>
								</div>
						
					<div x-show.transition.in="step === 11">

						<div class="mb-5">
							<label for="password" class="font-bold mb-1 text-gray-700 block">Set up password</label>
							<div class="text-gray-600 mt-2 mb-4">
								Please create a secure password including the following criteria below.

								<ul class="list-disc text-sm ml-4 mt-2">
									<li>Lowercase letters</li>
									<li>Numbers</li>
									<li>Capital letters</li>
									<li>Special characters</li>
								</ul>	
							</div>

							<div class="relative">
								<input
									:type="togglePassword ? 'text' : 'password'"
									@keydown="checkPasswordStrength()"
									x-model="password"
									class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 bg-gray-200 font-medium" name="password" required
									placeholder="Your strong password...">

								<div class="absolute right-0 bottom-0 top-0 px-3 py-3 cursor-pointer" 
									@click="togglePassword = !togglePassword"
								>	
									<svg :class="{'hidden': !togglePassword, 'block': togglePassword }" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-current text-gray-500" viewBox="0 0 24 24"><path d="M12 19c.946 0 1.81-.103 2.598-.281l-1.757-1.757C12.568 16.983 12.291 17 12 17c-5.351 0-7.424-3.846-7.926-5 .204-.47.674-1.381 1.508-2.297L4.184 8.305c-1.538 1.667-2.121 3.346-2.132 3.379-.069.205-.069.428 0 .633C2.073 12.383 4.367 19 12 19zM12 5c-1.837 0-3.346.396-4.604.981L3.707 2.293 2.293 3.707l18 18 1.414-1.414-3.319-3.319c2.614-1.951 3.547-4.615 3.561-4.657.069-.205.069-.428 0-.633C21.927 11.617 19.633 5 12 5zM16.972 15.558l-2.28-2.28C14.882 12.888 15 12.459 15 12c0-1.641-1.359-3-3-3-.459 0-.888.118-1.277.309L8.915 7.501C9.796 7.193 10.814 7 12 7c5.351 0 7.424 3.846 7.926 5C19.624 12.692 18.76 14.342 16.972 15.558z"/></svg>

									<svg :class="{'hidden': togglePassword, 'block': !togglePassword }" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-current text-gray-500" viewBox="0 0 24 24"><path d="M12,9c-1.642,0-3,1.359-3,3c0,1.642,1.358,3,3,3c1.641,0,3-1.358,3-3C15,10.359,13.641,9,12,9z"/><path d="M12,5c-7.633,0-9.927,6.617-9.948,6.684L1.946,12l0.105,0.316C2.073,12.383,4.367,19,12,19s9.927-6.617,9.948-6.684 L22.054,12l-0.105-0.316C21.927,11.617,19.633,5,12,5z M12,17c-5.351,0-7.424-3.846-7.926-5C4.578,10.842,6.652,7,12,7 c5.351,0,7.424,3.846,7.926,5C19.422,13.158,17.348,17,12,17z"/></svg>
								</div>
							</div>
							
							<div class="flex items-center mt-4 h-3">
								<div class="w-2/3 flex justify-between h-2">	
									<div :class="{ 'bg-red-500': passwordStrengthText == 'Too weak' ||  passwordStrengthText == 'Could be stronger' || passwordStrengthText == 'Strong password' }" class="h-2 rounded-full mr-1 w-1/3 bg-gray-300"></div>
									<div :class="{ 'bg-orange-400': passwordStrengthText == 'Could be stronger' || passwordStrengthText == 'Strong password' }" class="h-2 rounded-full mr-1 w-1/3 bg-gray-300"></div>
									<div :class="{ 'bg-green-400': passwordStrengthText == 'Strong password' }" class="h-2 rounded-full w-1/3 bg-gray-300"></div>
								</div>
								<div x-text="passwordStrengthText" class="text-gray-500 font-medium text-sm ml-3 leading-none"></div>
							</div>

							
						</div>

					</div>
								<div x-show.transition.in="step === 12">
							<label for="photo" class="font-bold mb-1 text-gray-700 block">Upload Your Photo</label>	
									<div class="text-gray-600 mt-2 mb-4">
									<ul class="list-disc text-sm ml-4 mt-2">
									<li>Complete Your Profile By Adding Your Profile Photo</li>

								</ul>	
									</div>
									
						<br>
						<div class="mb-5 text-center">
							
							<div class="mx-auto w-32 h-32 mb-2 border rounded-full relative bg-gray-100 mb-4 shadow-inset">
								<img id="image" class="object-cover w-full h-32 rounded-full" :src="image" />
							</div>
							
							<label 
								for="fileInput"
								type="button"
								class="cursor-pointer inine-flex justify-between items-center focus:outline-none border py-2 px-4 rounded-lg shadow-sm text-left text-gray-600 bg-white hover:bg-gray-100 font-medium">
								<svg xmlns="http://www.w3.org/2000/svg" class="inline-flex flex-shrink-0 w-6 h-6 -mt-1 mr-1" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
									<rect x="0" y="0" width="24" height="24" stroke="none"></rect>
									<path d="M5 7h1a2 2 0 0 0 2 -2a1 1 0 0 1 1 -1h6a1 1 0 0 1 1 1a2 2 0 0 0 2 2h1a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2" />
									<circle cx="12" cy="13" r="3" />
								</svg>						
								Browse Photo
							</label>

							<div class="mx-auto w-48 text-gray-500 text-xs text-center mt-1">Click to add profile picture</div>
							
							<input name="photo" id="fileInput" accept="image/*" class="hidden" type="file" @change="let file = document.getElementById('fileInput').files[0]; 
								var reader = new FileReader();
								reader.onload = (e) => image = e.target.result;
								reader.readAsDataURL(file);">
									</div>
					
					</div>
				</div>
				</form>
				
				<!-- / Step Content -->
			</div>
		</div>

		<!-- Bottom Navigation -->	
		<div class="fixed bottom-0 left-0 right-0 py-5 bg-white shadow-md" x-show="step != 'complete'">
			<div class="max-w-3xl mx-auto px-4">
				<div class="flex justify-between">
					<div class="w-1/2">
						<button 
							x-show="step > 1"
							@click="step--"
							class="w-32 focus:outline-none py-2 px-5 rounded-lg shadow-sm text-center text-gray-600 bg-white hover:bg-gray-100 font-medium border"
						>Previous</button>
					</div>

					<div class="w-1/2 text-right">
						<button 
							x-show="step < 12"
							@click="step++" 
							class="w-32 focus:outline-none border border-transparent py-2 px-5 rounded-lg shadow-sm text-center text-white bg-blue-500 hover:bg-blue-600 font-medium"
						>Next</button>

                        
<button id="success"  @click="step = 'complete'" style=""></button>
						<button type="submit" id="form_submit_btn" name="submit" 
						   
							x-show="step === 12"
							class="w-32 focus:outline-none border border-transparent py-2 px-5 rounded-lg shadow-sm text-center text-white bg-blue-500 hover:bg-blue-600 font-medium" 
						>Complete</button>
					</div>
				</div>
			</div>
		</div>
		<!-- / Bottom Navigation https://placehold.co/300x300/e2e8f0/cccccc -->	
	</div>

	<script>
		function app() {
			return {
				step: 1, 
				passwordStrengthText: '',
				togglePassword: false,

				image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAAAAAAAD/4QBCRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAkAAAAMAAAABAAAAAEABAAEAAAABAAAAAAAAAAAAAP/bAEMACwkJBwkJBwkJCQkLCQkJCQkJCwkLCwwLCwsMDRAMEQ4NDgwSGRIlGh0lHRkfHCkpFiU3NTYaKjI+LSkwGTshE//bAEMBBwgICwkLFQsLFSwdGR0sLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLP/AABEIAdoB2gMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APTmZsnmk3N60N1NJTELub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lFAC7m9aNzetJRQAu5vWjc3rSUUALub1o3N60lJQA7c3rSbm9aSigBdzetG4+tJRQAZPrRuPrSUUALub1/lRub1pKSgBdzUbm9aSigBdzetG5vX+VJSUALub1/lUu5qhqXj1oAG6mkpW6mkoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooASiiigAooooAKSiigAooo+lACUZoooAKKKSgAo/rRSUALUlRVJz60AObqaSlbqaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkoooAKKKKACiikoAKSlooASiiigA+lHpRQaACkoooATmilpPegBP/ANdS5HrUdSfL7UAObqaSlbqaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKSiigAooooAKKKKAEooooASij60UAFFFHpQAUmaKPxoAKSlpPWgA/wAmk/pS/Sk47dqADpUvPvUXrUn4H8qAHt1NJSt1NJQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFISFBJIAHUk4FAC0VTlv4EyEBc+3C/nVSS9uX6MEHonX8zQBrEqvLEAe5A/nUTXVqvWVfwyf5VjFmY5Ykn3JP86SmBrG/tB3c/RTTf7QtvST8hWXRQBqi/te+8f8AAc09by0b/loB/vAiseigDeV43+66t9CDTq5/p04+lTJdXMfSQkej/MP1oA2qKoR6gpwJUK/7Scj8utXEkjkG5GDD2P8AMUgH0UUUAFFFJQAUUUUAFFFJQAtJRRQAUlFFABR2oo+lAB1pKKP60AFFFFACUHjNH/66KAEpaSj/APVQAc0/I9KZUufpQA5uppKVuppKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACimsyopZiAo5JNZlxePLlI8rH0J/ib60AWp72KLKph3/wDHR9TWdLNNMcuxPoOij6Co6KYBRRRQAUUUUAFFFFABRRRQAUUUUAFKruhDIxUjuDikooA0IL/os4/4Gv8AUVfBVgCpBB6Ecg1gVLBcSwH5eUP3lPQ/SgDaoqOKaOZdyH/eB6qfepKQBRRRQAlFFFABSUUUAFFFFABRRSf5NABxR6e1FJQAcUUUnP6UALSf5/GjvRz+FAB06d6KT6UGgA96kyf8mo//ANdP59P1oAlbqaSlbqaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACmu6RqzucKvJNKSACScADJJ7Csi6uDO2BkRqflHr7mgBLi5edu4QH5V/qagoopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACUUUUAPjkkiYOhwR+RHoa14J0nTI4YffX0NYtPileJ1dDyOoPQj0NAG7SUyKVJkDr36juD6U+kAUhoooAKKKKACij/JpKACj/PNFFABScUelFACUdqP8mj+dABn9KMjij60d+tACf5FH5Uf59qOOlACfhUn40zmn4oAlbqaSlbqaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKhuJhDEz/xfdQerGgCpfXGT5CHgf6w+/8AdqhQSSSScknJPqTRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkoooAKKKKACiiigCe2nMEnP+rbhx6e9bHoQevT3zXP1p2M+9DE33k5X/AHf/AK1AF2koNFIAoopKAFpKKPSgApPX0pf8mkoAKKTPP1paAE+lFFIT/ntQAelHAoz0oz/hQAd6T155oooAKk2+wqLPt/8AWqTj1P5GgCZuppKVuppKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArJvpd8uwH5Y+P+BHrWnK4jjkc/wAKkj69qwiSSSepJJ+ppgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSUUUAFFFFABRRSUAFFFFABT4pDFIkg/hPPuO4plFAG8CGAYchgCD7HmlqpYy74dp6xnH4HkVapALSUUUAH+NFFJQAc0f5+tHFJQAUUUepoAP/r0nP/1sUH1ozQAUnOaPwo9OlAAcd6T60tJQAHn+lSZPotR/55qTJ/yKAJm6mkpW6mkoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAKWoPiNE/vtk/RazKt6g2Zgv9xB+Z5qpTAKKKKACiiigAooooAKKKKACiiigAooooAKKKSgAooooAKKKSgBaSiigAooooAKKKSgC3YPtmKdpFI/EcitSsOJiksTejr+Wa3PSgAoo/zzSflSAWkNBo/nQAlH9aPr60envQAf5NJS0noaADNFH+fYUH/61ACUetFJnGaADg//AK6O/NJ6fhRz0PrQAH/CpefVfzqI46ZNS8UATN1NJSt1NJQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAYt0d1xOf9rA/AYqGnzHMsx/6aP/ADplMAooooAKKKKACiiigAooooAKKKKACiikoAKKKKACiikoAWkoo4oAKKKKACiikoAKWkooAOa3UOUjb1VT+lYVbUB/cwHuY1JoAkz+dGTR2pP5UgAn+lFFHNABSfjzS0nFABn2+lFFIfQj6UAB6c0elH+eKT/JoAPU/wD6qOaPUe1HpQAho+tHXp+lJ/8AqoAOPXrT8H0H50z/ADxUmT6n9KALDdTSUrdTSUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAGFL/AK2b/ro/8zTKluBiecf7Z/XmoqYBRRRQAUUUUAFFFFABRRRQAUUUUAJRRRQAUUUUAFJRRQAUUUUAFFFJQAtJRRQAUUUUAFbUH+og/wCua/yrFrbjGI4h6Io/SgB/NJR60H2pAB/Wj0o5ooATPSjj/P8A9ej/APVSelACn/PrSccYo/z/APXpPf8A/VQAo9KSg9OfX+VHIoAOo7/1pp/P0+lO/Wm8/wD6qAD07dfxo4/Wj9fekyOp/wAigBc9fqKk/Koj39sVLlvf9KALDdTSUrdTSUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAGRfLtuGP95Vb9MVWrQ1FP9TJ9UP8xWfTAKKKKACiiigAooooAKKKKACkoooAKKKKACkpaSgAooooAKKKKACkpaSgAooo5oAKKKSgByjcyL6sAPxrcHHHoMYrJs033Ef+zlz+HStf1xQAn+eKPSj/AD9aPxxSAQ8UUUnrzQAtJn6UZP8An2o5/wA+9ACHt+dHPt3/AP1Uen8qM/rQAZ/wpP8APt60f55o5/rmgA9+1J680fyo7mgBD+H0o6Z4o9/T60UAJz05p/Pv+dM/PnGKk59BQBabqaSlbqaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAguo/MgkUdQNy/Veaxq6CsS5i8qZ1/hJ3L9DTAiooooAKKKKACiiigApKWkoAKKKKACiikoAKKKKACiiigApKWkoAKKKKACiikoAKKKACSoHUkAY96ANDT0wskh/iIUfQcmr3/AOumRRiKNIx/CBn3PenfmaQC+lFJzzQe/wCtAB/k0nX8fSlJpBgcfj+FABRwfw6Un+TRnt+dAB9KT1xR24+uaKAA/wD6/ek6c0fnzQeP55oAPekOf896OOvPTrR+VABwTgen60hwADRS/T8KAEPJ+vTNSc+v8qj5/wAfwqTP0/OgC03U0lK3U0lABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAVUvofMj3qPnjyfqverdFAHP0VYuoDDIcD92+Snt6iq9MAooooAKKKSgAooooAKKKSgAooooAKKKPagAoopKAFpKKKACiiigApKKKACrljFucyt0ThfdqqojSOqJ1Y4+nqa2Y0WNFReijH196AHUpopO34UgD/J5pP1o/w/Wj+tAAcfnzR/hRz9fSk4/wA/yFAB/k0Z46/Wjpn+tJ+NAAT3P6daT/PtS+tJQAd/0o5pOuOaO340AH+Tn1pAf8il9c+lJQAdPWjn/D2oP4e9Hp9PxoATPNSc+g/Sou3SpMD0NAFxuppKVuppKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjmiSZGRu/IPofWsWSN4nZHGCP19xW9Ve5t1nXsJF+639DQBj0UrKyMysCGBwQabTAKKKKACiiigAopKKACiiigAopKKACiiigAoopKACiiigAzR1xjJNFaNpa7MSyj5uqKf4c9z70ASWlv5K7m/1jdf9kelWT3o/E/Wk/pSAPr6/wA6P50cGk6ZoAP0/Gj/APXRQf8AOKAEx9Pzo59f/r0HH5f1pP6UALx1FJ6cjPOfx7Ufp/jRx6/0oATnijpx+VGc/SkOefT8qAD+p9aD+uaOnNJj88/hQAuaT+lHrzSe/Hv3oAWkyP8APFGeg7d8Un/6qAD8sfrTvl9f1FN6YH6U/j0P5UAXW6mkpW6mkoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAguLZJ154cD5W/oayJIpImKOMHt6EeoNbtMkijlUq6gjt6g+oNAGFRVqezliyyZdOvH3h9RVWmAUlLSUAFFFFABRRRQAUlLSUAFFFFABRRSUAH+RQASQACWPAAHJNSw280x+VcL3Y9K04beKAZHL92P8qAIba0EeHlwXHReoX/AOvVz/Cj0opAJz+dH+FH5/Wk9f8AOKAD9P1o9f60c8Z70Z+lACUfnRRxx+vtQAnr/Wg5/wA9qP8AHvRxj86AE9M96Mn8aOOlJ/8Aq9aAD1/TPWk649sUvfr/AIUnH9KADP6Uf40H/wDX60c/l1oAOvpR/h+FJke/40nPHtn60AGee31NJ6+/tS8dun9fxpOOmPcUAL/hUmR/tfrUJ7/zNSZb1P50AXm6mkpW6mkoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApKKKACiiigAqvNaQS5ONr/3k/qKsUlAGTLZXEedo3qO69fxFViCDgggjseDW/THjikGHRW+o5/OmBhUVqPYW7fdLp9DkfkahbTn/AIJQf94Y/lQBQoq2bC5GeYz9G/8ArUn2G69F/wC+hQBVoq0LG6PUIPq3+FPGnyn70iD6ZNAFKk/nWmunwjG93b8lFWEggj+5GoPTJGT+ZoAyo7a4kxtQhfVuBV2KxiTBkO8+nRfyq37Ht0ooAOAMDoPQYx9KKOn6UnFIAoo/z+dHagA4pMf5NFHagA+h59KTtR36fjRkc+tAB60n8/8APpSikJFACc+/09qPp75o/wA+oo4zQAZ6+vv/ACpOOPz/ABo6ZyaQ9vb0oAM9vzo/CjPtR2/oaAA496ODx7c0h9+9HJx70AJ3+lHHTP8A9ej8MUnHFAB3o54AoPP50h9fc8UAH+NScev+fzqPp/SpMH/P/wCugC83U0lK3U0lABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUlLSUAFFNeSOMbnYKPfv9BVKXUByIUz/tP/QUAX/X0qB7q2jyC4J9E5P6cVlSTzy/fckenQfkKjpgaJ1FMjETbe5JGfyqzHPBN9xxn0PDfkaxKP8AIoA3/wDPNFY8d3cx4G/cPR+f1q0mop/y0jI91Of0NIC9RUC3dq3/AC0A9mBFSh425DKfoRQA6ko560c+9ABSetLzTSyrncyj6kD+dAC9sUVC1zbLnMi/hz/KoGv4QPkVmPv8ooAuU15I4wS7Ko9zyfwrMkvrh+m1B/s8n8zVYlmOWYknuTk/rTA0X1CINhEZl7nO3P0FPS9tn6sUP+0OD26isqigDdBBGVIOeRtIP8qM9P8A9dYaO8ZJRmU/7JIq1HfyLxIoceo4b/CgDSIpOc1HFPDL9x8nH3Tww/CpM89KQBn/AOtQaT3/ADo/+vQAetJxijPWjigA6fypOOKO3PP1oPTr1zxQAf070np/n9aOaXuaAE4/+tR9Ov8AKg5PNJ+npQAHr/nmk4wc/wD6qMZ/z+NHH6fjQAentR/n2NJ+P/66P69qAD1H696THI+lH40hP+fagBeff2471Jg+pqI+nPT6VJuj9/zNAF9uppKVuppKACiiigAooooAKKKKACiiigAooooAKKKKACkpaimnigXLnk/dUdTQBISqgkkADqTwKoT34GVgGT/fbp+AqpPcSzn5jheyjoKhpgOd3clnYs3qabRSUALSUUUAFFFFABSUtJQAUf59KKKAFDOOAzD8TS+ZL/z0f/vo02koAcXfuzfmTTevX9aKSgBaKPak9KACg0UUAFJRn/69H/1qAA0UH0pKAAZByOCPTircN9ImFly6+v8AEKqHJzRQBtJIki7oyGH6j6in5/8Ar1iJJJG25GII/I/hWjb3SS4DfLJ6HofcUgLPpSZ/z9aX1/XNJ6+npQAcY/Sj29vyo65/SjnP+eKAG/y/WjrS/wCfzo/+tQAn+FJ3x3o6f56UUAJyM8cUUuP8OvakNAB/+qk70ev50maAF5603PtS55Ppn1oPqfWgBOOn40/n0P6VHk8D396mx9aAL7dTSUrdTSUAFFFFABRRRQAUUUUAFFFFABRRRQAUUVXubhYF4wZG+4P6mgAublYBgYMh+6vp7msh3eRi7klj1J/kKGZnYsxJYnJJptMAooooASiiigAo9KKKACiiigBKKKKACiiigApKWkoAKSlooAKTpRRQAUlLSUAFHeik4oAOaKP5Uf8A1qACkooOaACjODkH6e1Ic0UAaFtdlsRyn5sYVvX0Bq7nH096wsjmtC1ut+IZD83ARj3HoaALnXpQCcUfyo5+n+NIBOmaQ85pc89PxpPc8Dt/jQAh7evb8KU+tGevToTSenp3oAD9f/rUe3NJxkf5zR+PpigA57DnFJij6+lB9fWgAJFNPt/9elOfr/8AXpOP6e1AC+n+f1p2D/kmmf0/lUv4f5/KgDQbqaSlbqaSgAooooAKKKKACiiigAooooAKKKT1z2oAjmlSFGdu3AH94+lY0kjyOzuclj+XsKlupzNIcH92nCD196r0wCiiigAopKKACiiigAooooAKSiigAooooAKKKSgAo/z+NFFACcUUUUAFFFJQAUZoozQAlH50c0cUAFFFIfp/9agAo4oooASiiigBPTAoyfp3H/1qP8/nRQBqWtwJV2Mf3i9f9oetT8n61io7RsrqeVPHv7VsRyLIodeh5we3saAHd+Pxo9/84pOOv6mjn8+lIA9/zNJ69aX+VJ6e3WgA6elJye1LwfWkoAMdf0pD29s80uTjGfzpM57UAH8vz/Sk+oo/zn/61J0/GgBe4x6fp9Kkz7fpUf8An8aftP8AkigDSbqaSlbqaSgAooooAKKKKACiiigAooooAKpX0+xBEp+aTr7L/wDXq4SACTwACT9BWHNIZZHkPc8D0UdBQBHRRRTAKSiigAooooAKKKKACkoooAKKKKACkpaSgAoozRQAUUnPNFAB+dFFFABxSc0UUAJn9KKKOlABR/Wj/P1pOKACijmkoAKKKKAE/OjFFHGcUAHr+VHvRxSH2oAP8irVnNsfyz91zgZ7NVWjv+ORz0oA3OvUe4pPzqKGQSxK38XRvqOKk/8A1c+9IA9O3+e9HXjPP6UmeaD6CgAJ6Y9eaD0/mc0f5/Cm/wCf/r0AL+FJ/P8AzxR/niloAT/PsPaj+XbP+NHXP6UnX/69AB/Xr/OpMH3pnHv2qTn1P50AaLdTSUrdTSUAFFFFABRRRQAUUUUAFJRRQBUv5dkQQfekOP8AgI5NZVWb2TfOw7RgIPr3qtTAKKKSgAooooAKKKKACiikoAKKKKACiikoAWkoooAKSiloAT/PFFFFACf4UUdaM0AHY0nPY0UUAFFFJxxigAo/Gj+tFABSZoooAPcelFJ/+ujigA/yaKP88UGgBKPxo96KAEo7/jR3o70AW7GTDmPPDjI/3hWgTWKrbGVx/CQfy7VsghgpHQgE/jQAdf0zQf8AH86D+ntScc+nvSAPrnmj9P8A69JnpQM8fXJ7UAH+foaT29sClPXjHvSf4d6ADPtRkdPxpe3Xt9KT06ewoAOKlwPX9Ki44H4c80/H+cUAabdTSUrdTSUAFFFFABRRRQAUlLSUAFNdgiO56Kpb8hTqrXzbbdx3cqv9aAMgkkknqSSfx5oopKYC0lFFABRRRQAUlFFABRRRQAUUfhRQAUlHJooAPSkpe1JQAp/CkoNFABSUv1pKADpR60UlABx+dFFH6igBKWjmkoAKSlzmkoAM/wCelHpSUc8+9AB+NH+FFBoAM8dKb29+tLnvR/P1oAPWk/OjvRzxQAUUUnH60AHr6Vp2jhoQCTlMr/Wsw1csW5lT1Ab8uKAL3H4dKKP/ANXSjpn260gE7+vejijB/L9KTjII/wAmgBfek+n4fWl5GaD7flQAh9c59MUUcD+VH+cCgA7HH59qlyfb8jUX0HfvzzT+f7woA026mkpW6mkoAKKKKACiikoAKKKKACqGotxCnqWY/hxV+svUT+9Qekf8yaAKdJRRTAKKKKACkpaKAEooooAKKKKACkoooAKOwopPWgA/yKOKKKACkoo9f60AFJS5P+FJ6UAFHNFFABSUUUAGetBopPqaAD+fajrSZoPNAAf84oo9aOcf56UAHce1JzQeM0fSgA9aP85pP8KKAD0o49KKKAEzSelLmkzQAtTWhxOvuGX9M1BT4TtlhP8Atr+pxQBr/nxRzjJ/Gl56elJzxk0gE9Mk0vTuOf1o/wAf880fLQAnXp0/w9KPx9qP8k0f1zQAfjwKPbtzQPp/9ek49eOc0AGfY5Gafg+tMz7egp+1ff8AMUwNRuppKVuppKQBRRSUAFFFFABRRSUALWTf/wCv/wCALWrWVf8A+v8A+ALTAqUUUUAFFFJQAUUUUAHeiiigApKKPxoAPrRRRQAUlFHFAB/+rmg0UlAAaM0dDSfTpQAGiiigA4pKWkFAAaOaDSdqAD0ozR3pKACiiigA9Pb1pPalNJQAUZ+lJRQAGiij/wCv7UABpPWgnv0ooAPxpKKOmRQAdv8AGlj/ANZH/vr/ADpvH9adH/rI/wDfX+dAG0SMnpSY9KM/oaDn8/TikAeuPoaTH55OaOO1HPv/AI0AJ07Dpz6Gl9Pf+tJ0zx1/l1pc8fTpQAn+B5o9Onf15o5wT24zSHpwPwFMA44qTLepph/w+lPw3oaANRuppKVuppKQBSUUUAFFFFABSUUUAFZV/wD8fH/AFrVrJv8A/X/8AWmBVpKWkoAWkoooAKKKKACiikoAKKKDQAUlHtRQAUUUlAAaKPxpKAA0dOlFFABR/Sk5zR/KgBaSiigApO9FH+fxoAP8aPSk6+1J+NAC9x/n86M/5FH50lABRRSUALSUe/p60UAH86TP5UUmaAD0xRR/n6Uf5NAB70UUn/66ADinR/6yP/fU/rTeP8M0sf34+f41/nQBtZ/w/wDrc0nXsPwo/wAg0HvmkAen40Z70n6Z6fj2oIH59aAF70nP4Uf4YoPtxn9KYCc8eoxilznPWj+dJQAdR04NSZPoPzqOpMf5xSA1G6mm05upptABRRRQAUlLSUAFFFFACVlX/wDr/wDgC1q1lX/+v/4AtMCpRRRQAUUUUAFFFJQAUUUUAFJS0lABSUvpSUALSUUE+1ACUUfrRQAetJS0lAC5pP1oooASij2o9fc0AFH0pPT/ADmigAz9cUetHf8ADtSGgAycmjp/hR/+uj60AJR3oo+negAo6UnvRntQAGk9aX86SgAP40nFL+PekoAPX9KKPWk/yaAFpY/vx/768/jSUsePMj9d6/qaANk55+tH8v5UYoHT3HOD70gD/HvSf5/+tR6j19aOP8DTAOMd6Dx0+n/1qP8AI/nQe/tQAdO/5dqSl7Hpn3pPXikAemPp3qbI9aiHWpcD1NAGi3U0lS+n0H8qKAIqKk7UUARUVJQO9AEX+eKKlPb6UnYUAR1lX/8Ar+f7i1telZF//rx/uL/WmBRoqT/61JQAyipP/r0nc/57UAMpKkPf8KO5oAjop56Cg/0oAjop9Hp+FADKSnnrRQAyk61Ieg/Gjt+NAEdH+RUh6fjSDtQAz+dJ0qQ9/wDPakPSgBhpKlPT/PpSHvQBHzSf4mn+v4UGgBnej/PNSdjSdj9BQBH/AIUU80H7v5UAMpDUn9360Dv/AJ70AR/l0o9aef6UD/GgCPij+dSDr+dIe9AEdIal7fjTfX6UAMoz+dOPT8aWgBn+NJUvp+NN/wABQAzmnJ9+P/eX+dKO9SR/6yH/AHx/MUAanH+fekzUnYfSl9f8+lICLj+lH/6/6VKf4P8Ad/wpq/dpgM/Cgc9e2akPf/dpO/4D+YpAM6//AF+v5UZPH+cVJ3/E0rd/+BUAQ89fQcj2qXn1/nR3j+lNPVvqaAP/2Q==',
				password: '',
				gender: 'Male',

				checkPasswordStrength() {
					var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
					var mediumRegex = new RegExp("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");

					let value = this.password;

					if (strongRegex.test(value)) {
						this.passwordStrengthText = "Strong password";
					} else if(mediumRegex.test(value)) {
						this.passwordStrengthText = "Could be stronger";
					} else {
						this.passwordStrengthText = "Too weak";
					}
				}
			}
		}
	</script>
<script>
	var input = document.querySelectorAll('#js-date')[0];
  
var dateInputMask = function dateInputMask(elm) {
  elm.addEventListener('keypress', function(e) {
    if(e.keyCode < 47 || e.keyCode > 57) {
      e.preventDefault();
    }
    
    var len = elm.value.length;
    
    // If we're at a particular place, let the user type the slash
    // i.e., 12/12/1212
    if(len !== 1 || len !== 3) {
      if(e.keyCode == 47) {
        e.preventDefault();
      }
    }
    
    // If they don't add the slash, do it for them...
    if(len === 2) {
      elm.value += '/';
    }

    // If they don't add the slash, do it for them...
    if(len === 5) {
      elm.value += '/';
    }
  });
};
  
dateInputMask(input);
	</script>
<script>
	
var telInput = $("#phone"),
  errorMsg = $("#error-msg"),
  validMsg = $("#valid-msg");

// initialise plugin
telInput.intlTelInput({

  allowExtensions: true,
  formatOnDisplay: true,
  autoFormat: true,
  autoHideDialCode: true,
  autoPlaceholder: true,
  defaultCountry: "auto",
  ipinfoToken: "yolo",

  nationalMode: false,
  numberType: "MOBILE",
  //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
  preferredCountries: ['in'],
  preventInvalidNumbers: true,
  separateDialCode: true,
  initialCountry: "in",
  geoIpLookup: function(callback) {
  $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
    var countryCode = (resp && resp.country) ? resp.country : "";
    callback(countryCode);
  });
},
   utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"
});

var reset = function() {
  telInput.removeClass("error");
  errorMsg.addClass("hide");
  validMsg.addClass("hide");
};

// on blur: validate
telInput.blur(function() {
  reset();
  if ($.trim(telInput.val())) {
    if (telInput.intlTelInput("isValidNumber")) {
      validMsg.removeClass("hide");
    } else {
      telInput.addClass("error");
      errorMsg.removeClass("hide");
    }
  }
});

// on keyup / change flag: reset
telInput.on("keyup change", reset);



	
	
	
	</script>
	
<script>
$('#otp').hide();
$('#verify').hide();
$('#resend').hide();
$('#send').on('click',function(){
$('#mb').hide();
$('#send').hide();
$('#otp').show();
$('#verify').show();
$('#resend').show();
});
$('.fa-arrow-left').on('click',function(){
$('#mb').show();
$('#send').show();
$('#otp').hide();
$('#verify').hide();
$('#resend').hide();
});</script>                   
                    
	
	<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>	

<script>
$(document).ready(function(){
$("#form_submit_btn").click(function(){
	var formdata = document.getElementById("signup_form");
	var formData = new FormData(formdata);

        $.ajax({
            type:'POST',
            url: "../includes/create_new_account.php",
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				console.log("success");
                console.log(data);
				
                if(data=="CREATED"){					
					$("#success").trigger("click");
				}else{
					$("#e_m").html(data);

				}
            },
            error: function(data){
				console.log("error");
                console.log(data);
				
                
            }
        });

});
});
</script>	
</body>

</body>
</html>

