<?php
require_once('Database.php');
error_reporting(0);
class DB{
static $database;
protected $first_name;
protected $last_name;
protected $gender;
protected $d_o_b;
protected $email;
protected $mobile;
protected $password;
protected $location;
protected $loc_lat;
protected $loc_long;
protected $qualification;
protected $working_status;
protected $looking_for;
protected $business;
protected $business_about;
protected $business_plan;
protected $image;

public function __set($property, $value) {
    if(!is_array($value)){
        $this->$property = mysqli_real_escape_string(self::$database,$value); 
    }else{
        $this->$property = $value; 
    }
    
     
  }

function __construct(){
    self::$database=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME) or die("Database is not connected !");
}

function uploadImage($tmp){
    $imagename =time().$this->image;
    if(move_uploaded_file($tmp,"../public/images/$imagename")){
        return $imagename;
    }
    return false;
        }
        
}
?>