<?php
require_once('MainController.php');
class Signup extends DB{

    
   function isMobileAlreadyRegistered($mobile){
$query="SELECT * FROM users WHERE mobile='$mobile'";
$d = mysqli_query(self::$database,$query);
$f = mysqli_fetch_array($d);
if(count($f)>0){
    return true;
}
return false;
   }
   function isEmailAlreadyRegistered($email){
    $query="SELECT * FROM users WHERE email='$email'";
    $d = mysqli_query(self::$database,$query);
    $f = mysqli_fetch_array($d);
    if(count($f)>0){
        return true;
    }
    return false;
       }   
    function createAccount($img){
        $imagename = $img;
        if($imagename!=false){
            $query="INSERT INTO users (first_name,last_name,gender,d_o_b,email,mobile,password) ";
            $query.="VALUES ( ";
            $query.="'$this->first_name',";
            $query.="'$this->last_name',";
            $query.="'$this->gender',";
            $query.="'$this->d_o_b',";
            $query.="'$this->email',";
            $query.="'$this->mobile',";
            $query.="'$this->password'";
            $query.=" )";

            if(mysqli_query(self::$database,$query) or die("user query not running")){
                $userid = mysqli_insert_id(self::$database);
                $query="INSERT INTO users_profile (user_id,image) ";
            $query.="VALUES ( ";
            $query.="$userid,";
            $query.="'$imagename'"; 
            $query.=" )";
            if(mysqli_query(self::$database,$query)){
                $bfix = implode("#",$this->business);
                // return $bfix;
                
                
                $query="INSERT INTO users_information (user_id,location,loc_lat,loc_long,qualification,working_status,looking_for,business,business_about,investment) ";
            $query.="VALUES ( ";
            $query.="$userid,";
            $query.="'$this->location',";
            $query.="'$this->loc_lat',";
            $query.="'$this->loc_lang',";
            $query.="'$this->qualification',";
            $query.="'$this->working_status',";
            $query.="'$this->looking_for',";
            $query.="'$bfix',";
            $query.="'$this->business_about',";
            $query.="'$this->business_plan'";
            $query.=" )";
            if(mysqli_query(self::$database,$query)){
                return "CREATED";
            }
            }

            }
        }
return false;
    }
}
?>