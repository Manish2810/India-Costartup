<?php
require_once('../Controller/User.php');
if(!$_SESSION['isUserLoggedIn']){
    header("location:signin.php");
}

$user = new User;
$user->id=$_SESSION['id'];
$userdata = $user->getUserById();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
<h1>Welcome, <?=$userdata['first_name']?> <?=$userdata['last_name']?></h1>
<p><?=$userdata['email']?></p>
<br>
<a href="../includes/logout.php">Logout</a>
</body>
</html>