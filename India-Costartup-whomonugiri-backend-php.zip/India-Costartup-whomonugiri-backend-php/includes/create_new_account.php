<?php
require_once("../Controller/Signup.php");
// echo "<pre>";

if(isset($_POST['first_name'])){
   $error=false;
   $message="";
foreach($_POST as $key=>$value){
   if($key=='otp' || $key=='loc_lat' || $key=='loc_long'){
      continue;
   }
    if($value==''){
       $error=true;
       $message="Please enter all the details";
       break;
    }
}


if(!$error){
   
   $user = new Signup;
   if($user->isMobileAlreadyRegistered($_POST['mobile'])){
      echo "Mobile number already registered !";
      $error=true;
   }else if($user->isEmailAlreadyRegistered($_POST['email'])){
      echo "Email Id is already regsitered !";
      $error=true;  
   }else if($_FILES['photo']['name']==''){
      $error=true;
      echo "Please upload profile picture";
   }
   if(!$error){
      $user->first_name=$_POST['first_name'] ?? null;
      $user->last_name=$_POST['last_name'] ?? null;
      $user->gender=$_POST['gender'] ?? null;
      $user->d_o_b=$_POST['d_o_b'] ?? null;
      $user->email=$_POST['email'] ?? null;
      $user->mobile=$_POST['mobile'] ?? null;
      $user->password=$_POST['password'] ?? null;
      $user->location=$_POST['location'] ?? null;
      $user->loc_lat=$_POST['loc_lat'] ?? null;
      $user->loc_lang=$_POST['loc_long'] ?? null;
      $user->qualification=$_POST['qualification'] ?? null;
      $user->working_status=$_POST['working_status'] ?? null;
      $user->looking_for=$_POST['looking_for'] ?? null;
      $user->business=$_POST['business']??null;
      $user->business_about=$_POST['business_about'] ?? null;
   
      $user->business_plan=$_POST['businessplan'] ?? null;
   
     
      $user->image=$_FILES['photo']['name'] ?? null;
      echo $user->createAccount($user->uploadImage($_FILES['photo']['tmp_name']));
   }
  
}else{
   echo $message;

}
  

}


?>