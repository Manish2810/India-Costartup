-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2021 at 06:23 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indiacostartup`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `d_o_b` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `d_o_b`, `email`, `mobile`, `password`) VALUES
(39, 'Monu', 'Giri', 'Male', '14/07/1999', 'whomonugiri@gmail.com', '7838403916', 'password123'),
(40, 'Mohan', 'Goswami', 'Male', '23/23/2323', 'workwithmohan@gmail.com', '9554545454', 'vfgfdgdfgdfg');

-- --------------------------------------------------------

--
-- Table structure for table `users_information`
--

CREATE TABLE `users_information` (
  `id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `location` text NOT NULL,
  `loc_lat` varchar(255) NOT NULL,
  `loc_long` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `working_status` varchar(255) NOT NULL,
  `looking_for` varchar(255) NOT NULL,
  `business` varchar(255) NOT NULL,
  `business_about` text NOT NULL,
  `investment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_information`
--

INSERT INTO `users_information` (`id`, `user_id`, `location`, `loc_lat`, `loc_long`, `qualification`, `working_status`, `looking_for`, `business`, `business_about`, `investment`) VALUES
(29, 39, 'New Delhi', '', '', '13', '1', '1', 'Advertising & Marketing#Agriculture', 'this is my business idea', '3'),
(30, 40, '2sdsd', '', '', '16', '4', '2', 'Advertising & Marketing', 'zdfdsfsdf', '2');

-- --------------------------------------------------------

--
-- Table structure for table `users_profile`
--

CREATE TABLE `users_profile` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_profile`
--

INSERT INTO `users_profile` (`id`, `user_id`, `image`) VALUES
(26, 26, '1612022743Untitled-1.jpg'),
(27, 27, '1612022891Untitled-1.jpg'),
(28, 28, '1612023609Untitled-1.jpg'),
(29, 29, '1612023613Untitled-1.jpg'),
(30, 30, '1612023680Untitled-1.jpg'),
(31, 31, '1612023681Untitled-1.jpg'),
(32, 32, '1612023681Untitled-1.jpg'),
(33, 33, '1612023681Untitled-1.jpg'),
(34, 34, '1612023733Untitled-1.jpg'),
(35, 35, '1612023734Untitled-1.jpg'),
(36, 36, '1612025107Untitled-1.jpg'),
(37, 37, '1612025272Untitled-1.jpg'),
(38, 38, '1612025326Untitled-1.jpg'),
(39, 39, '1612026068profilepic.png'),
(40, 40, '161202622968734063_400750860548654_3356360415949204217_n.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_information`
--
ALTER TABLE `users_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_profile`
--
ALTER TABLE `users_profile`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users_information`
--
ALTER TABLE `users_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users_profile`
--
ALTER TABLE `users_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
